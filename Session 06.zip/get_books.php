<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//Connect to the server/db
$link = mysqli_connect("localhost", "root", "", "bookdb");
$query = "SELECT * FROM books";
$result = mysqli_query ($link, $query) or die ("query failed");

//Get books
$outp = "";
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	{

  if ($outp != "") {$outp .= ",";}
  $outp .= '{"ISBN":"'  . $row["isbn"] . '",';
  $outp .= '"Title":"'   . $row["title"]        . '",';
  $outp .= '"Author":"'. $row["author"]     . '"}';
		  
	}
$outp ='{"records":['.$outp.']}';
echo($outp);
mysqli_close($link);
?>   
